#' loadData
#' 
#' load all DoOR.data
#' 
#' 
#' @return attaches all DoOR data
#' @author Daniel Münch <\email{daniel.muench@@uni-konstanz.de}>
#' @examples
#' 
#' loadData()
#' 
#' @export loadData
loadData <- function(){
  all.data <- data(package = "DoOR.data")
  data(list = all.data$results[,3])
}

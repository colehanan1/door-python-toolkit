#' rescale the data values from 0 to 1
#' 
#' \code{DoORnorm} is used to normalize the data in values from 0 to 1.
#' 
#' 
#' @param x a numeric vector
#' @author Shouwen Ma <\email{shouwen.ma@@uni-konstanz.de}>
#' @keywords math
#' @export
#' @examples
#' x <- rnorm(10)
#' DoORnorm(x)
#' 
DoORnorm <- function(x) {
  if(all(is.na(x)))
     return(x)
  x.max <- max(x, na.rm = TRUE)
  x.min <- min(x, na.rm = TRUE)
  if ((x.max - x.min) == 0) {
    eval <- x - x
  } else { 
    eval <- (x - x.min) / (x.max - x.min) 
  }
  return(eval)
}
